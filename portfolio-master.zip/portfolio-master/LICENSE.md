Copyright © 2020 - [iuricode](https://github.com/iuricode)

O uso desses arquivos NÃO é permitido, caso queria usar como referência por favor entrar em contato (Links na bio dos contatos).
